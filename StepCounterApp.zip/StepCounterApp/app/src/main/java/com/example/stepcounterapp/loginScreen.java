package com.example.stepcounterapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class loginScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
    }

    private void homePage(View view) {
        Intent intent = new Intent(this, homeScreen.class);
        startActivity(intent);
    }

    public void submitLogin(View view) {
        EditText usernameEntry = (EditText)findViewById(R.id.usernameEntry);
        String username = usernameEntry.getText().toString();
        EditText passwordEntry = (EditText)findViewById(R.id.passwordEntry);
        String password = passwordEntry.getText().toString();

        userDatabase db = new userDatabase(loginScreen.this);
        db.open();

        if (db.Login(username, password)) {
            homePage(view);
        } else {
            //provide user feedback
        }
        db.close();
    }

    public void createAccountPage(View view) {
        Intent intent = new Intent(this, createUserLogin.class);
        startActivity(intent);
    }

}
