package com.example.stepcounterapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class homeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
    }

    public void stepInfoPage(View view) {
        Intent intent = new Intent(this, stepCountScreen.class);
        startActivity(intent);
    }

    public void caloireInfoPage(View view) {
        Intent intent = new Intent(this, calorieScreen.class);
        startActivity(intent);
    }

    public void weightInfoScreen(View view) {
        Intent intent = new Intent(this, weightScreen.class);
        startActivity(intent);
    }

    public void exerciseInfoPage(View view) {
        Intent intent = new Intent(this, exerciseScreen.class);
        startActivity(intent);
    }
}
